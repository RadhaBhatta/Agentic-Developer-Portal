import { Repository } from '../types';

export const MOCK_REPOS: Repository[] = [
  {
    id: 'repo-1',
    name: 'vortex-engine-core',
    description: 'High-performance distributed computing engine for real-time data processing.',
    language: 'Rust',
    stars: 1240,
    healthScore: 94
  },
  {
    id: 'repo-2',
    name: 'apollo-dashboard-ui',
    description: 'Enterprise-grade React dashboard template with built-in telemetry charts.',
    language: 'TypeScript',
    stars: 850,
    healthScore: 82
  },
  {
    id: 'repo-3',
    name: 'legacy-payment-gateway',
    description: 'Monolithic PHP service handling legacy transaction protocols. Critical maintenance required.',
    language: 'PHP',
    stars: 120,
    healthScore: 38
  },
  {
    id: 'repo-4',
    name: 'nebula-auth-service',
    description: 'Cloud-native authentication provider supporting OAuth2 and biometric verification.',
    language: 'Go',
    stars: 560,
    healthScore: 75
  },
  {
    id: 'repo-5',
    name: 'data-scraper-py',
    description: 'Automated web scraping utility with AI-driven content extraction.',
    language: 'Python',
    stars: 2100,
    healthScore: 61
  },
  {
    id: 'repo-6',
    name: 'zenith-mobile-app',
    description: 'Cross-platform mobile application built with React Native and Expo.',
    language: 'TypeScript',
    stars: 430,
    healthScore: 89
  }
];

// Optional: Specific log sequences for different agent tasks
export const AGENT_SEQUENCES = {
  REFactor: [
    "Initializing Refactor Agent...",
    "Analyzing cyclomatic complexity...",
    "Identifying redundant logic in /src/utils...",
    "Drafting optimized functional components...",
    "Applying changes and linting...",
    "Running unit tests...",
    "Refactor successful. 12% bundle size reduction."
  ],
  UPGRADE: [
    "Checking registry for latest versions...",
    "Analyzing dependency tree conflicts...",
    "Updating package.json entries...",
    "Running npm install / yarn...",
    "Verifying build integrity...",
    "Upgrade complete. No breaking changes detected."
  ]
};