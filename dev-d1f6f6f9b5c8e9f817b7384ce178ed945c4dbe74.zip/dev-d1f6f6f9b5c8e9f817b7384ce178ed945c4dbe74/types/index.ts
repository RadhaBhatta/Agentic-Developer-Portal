export type TaskStatus = 'idle' | 'running' | 'success' | 'failure';

export interface Repository {
  id: string;
  name: string;
  description: string;
  language: string;
  stars: number;
  healthScore: number;
}

export interface AgentState {
  logs: string[];
  status: TaskStatus;
  activeRepoId: string | null;
}