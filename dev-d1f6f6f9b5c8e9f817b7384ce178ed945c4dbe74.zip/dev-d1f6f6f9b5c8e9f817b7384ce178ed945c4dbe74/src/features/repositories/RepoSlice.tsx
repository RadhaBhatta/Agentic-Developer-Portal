import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import { Repository } from '../../types';
import { MOCK_REPOS } from '../../data/mockData';

interface RepoState {
  allRepos: Repository[];
  filteredRepos: Repository[];
  selectedRepoId: string | null;
  searchQuery: string;
}

const initialState: RepoState = {
  allRepos: MOCK_REPOS,
  filteredRepos: MOCK_REPOS,
  selectedRepoId: null,
  searchQuery: '',
};

export const repoSlice = createSlice({
  name: 'repositories',
  initialState,
  reducers: {
    setSearchQuery: (state, action: PayloadAction<string>) => {
      state.searchQuery = action.payload;
      state.filteredRepos = state.allRepos.filter((repo) =>
        repo.name.toLowerCase().includes(action.payload.toLowerCase())
      );
    },
    selectRepo: (state, action: PayloadAction<string>) => {
      state.selectedRepoId = action.payload;
    },
  },
});

export const { setSearchQuery, selectRepo } = repoSlice.actions;
export default repoSlice.reducer;