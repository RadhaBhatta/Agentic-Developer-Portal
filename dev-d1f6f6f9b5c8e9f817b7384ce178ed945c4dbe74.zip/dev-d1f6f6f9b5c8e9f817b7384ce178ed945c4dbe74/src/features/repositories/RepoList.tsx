import React from 'react';
import { useAppSelector, useAppDispatch } from '../../app/hooks';
import { setSearchQuery, selectRepo } from './repoSlice';
import { Input } from '../../components/ui/Input';

export const RepoList = () => {
  const { filteredRepos, selectedRepoId, searchQuery } = useAppSelector((state) => state.repositories);
  const dispatch = useAppDispatch();

  return (
    <div className="flex flex-col h-full bg-slate-900/50">
      <div className="p-4 border-b border-slate-800">
        <h2 className="text-sm font-bold text-slate-400 uppercase mb-3 tracking-wider">Explorer</h2>
        <Input 
          placeholder="Filter repositories..." 
          value={searchQuery}
          onChange={(e) => dispatch(setSearchQuery(e.target.value))}
        />
      </div>
      
      <div className="flex-1 overflow-y-auto">
        {filteredRepos.map((repo) => (
          <button
            key={repo.id}
            onClick={() => dispatch(selectRepo(repo.id))}
            className={`w-full text-left p-4 border-b border-slate-800/50 transition-all ${
              selectedRepoId === repo.id 
                ? 'bg-indigo-600/10 border-r-2 border-r-indigo-500' 
                : 'hover:bg-slate-800'
            }`}
          >
            <div className="font-medium text-slate-200 text-sm">{repo.name}</div>
            <div className="flex items-center gap-2 mt-1">
              <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-800 text-slate-400 border border-slate-700">
                {repo.language}
              </span>
              <span className={`text-[10px] font-bold ${repo.healthScore > 70 ? 'text-emerald-500' : 'text-amber-500'}`}>
                {repo.healthScore}% Health
              </span>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
};