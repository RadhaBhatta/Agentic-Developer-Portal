import React from 'react';
import { useAppSelector, useAppDispatch } from '../../app/hooks';
import { runAgentTask } from '../agent/agentSlice';
import { Card, CardTitle, CardContent } from '../../components/ui/Card';
import { Button } from '../../components/ui/Button';

export const RepoOverview = () => {
  const dispatch = useAppDispatch();
  const selectedId = useAppSelector((state) => state.repositories.selectedRepoId);
  const repo = useAppSelector((state) => 
    state.repositories.allRepos.find(r => r.id === selectedId)
  );

  if (!repo) {
    return (
      <div className="h-full flex items-center justify-center text-slate-500 italic">
        Select a repository to view AI-driven insights
      </div>
    );
  }

  return (
    <div className="p-8 max-w-5xl mx-auto animate-in fade-in duration-500">
      <div className="flex justify-between items-start mb-10">
        <div>
          <h1 className="text-3xl font-bold text-white mb-2">{repo.name}</h1>
          <p className="text-slate-400 max-w-xl">{repo.description}</p>
        </div>
        <Button 
          size="lg" 
          onClick={() => dispatch(runAgentTask(repo.name))}
        >
          🚀 Trigger AI Agent
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-10">
        <Card>
          <CardTitle>Health Score</CardTitle>
          <CardContent className={repo.healthScore > 70 ? 'text-emerald-400' : 'text-amber-400'}>
            {repo.healthScore}%
          </CardContent>
        </Card>
        <Card>
          <CardTitle>Popularity</CardTitle>
          <CardContent>{repo.stars.toLocaleString()} Stars</CardContent>
        </Card>
        <Card>
          <CardTitle>Tech Stack</CardTitle>
          <CardContent className="text-indigo-400">{repo.language}</CardContent>
        </Card>
      </div>

      <div className="bg-slate-900 border border-slate-800 rounded-xl p-6">
        <h3 className="text-white font-bold mb-4 flex items-center gap-2">
          <span className="h-2 w-2 rounded-full bg-indigo-500 animate-pulse" />
          Recommended Actions
        </h3>
        <div className="space-y-4">
          <div className="flex items-center justify-between p-3 bg-slate-950 rounded-lg border border-slate-800">
            <span className="text-sm text-slate-300">Upgrade dependencies to resolve 3 vulnerabilities</span>
            <Button variant="secondary" size="sm">Review</Button>
          </div>
          <div className="flex items-center justify-between p-3 bg-slate-950 rounded-lg border border-slate-800">
            <span className="text-sm text-slate-300">Refactor legacy authentication module</span>
            <Button variant="secondary" size="sm">Analyze</Button>
          </div>
        </div>
      </div>
    </div>
  );
};