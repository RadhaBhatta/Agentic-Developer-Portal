import React, { memo } from 'react';

interface LogStreamProps {
  logs: string[];
}

export const LogStream = memo(({ logs }: LogStreamProps) => {
  return (
    <div className="space-y-1">
      {logs.map((log, index) => (
        <div key={index} className="flex gap-3 group">
          <span className="text-slate-600 select-none w-8 text-right font-mono">
            {index + 1}
          </span>
          <span className="text-emerald-500/90 font-mono whitespace-pre-wrap break-all">
            {log.startsWith('[Agent]') ? (
              <span className="text-indigo-400 font-bold">{log}</span>
            ) : (
              log
            )}
          </span>
        </div>
      ))}
      <div className="h-4" /> {/* Bottom padding for scroll */}
    </div>
  );
});

LogStream.displayName = 'LogStream';