import React from 'react';
import { useAppSelector } from '../../app/hooks';
import { Badge } from '../../components/ui/Badge';

export const AgentStatus = () => {
  const { status } = useAppSelector((state) => state.agent);

  const getVariant = () => {
    switch (status) {
      case 'success': return 'success';
      case 'running': return 'warning';
      case 'failure': return 'danger' as any; // Using custom badge logic
      default: return 'outline';
    }
  };

  return (
    <div className="flex items-center gap-2">
      <span className="text-xs text-slate-500 font-mono uppercase tracking-tighter">Status:</span>
      <Badge variant={getVariant()}>
        {status === 'running' && (
          <span className="mr-1.5 h-1.5 w-1.5 rounded-full bg-amber-400 animate-pulse" />
        )}
        {status}
      </Badge>
    </div>
  );
};