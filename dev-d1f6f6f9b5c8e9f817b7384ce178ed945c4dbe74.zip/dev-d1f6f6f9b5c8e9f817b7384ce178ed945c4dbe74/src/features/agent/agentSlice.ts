import { createSlice, createAsyncThunk, PayloadAction } from '@reduxjs/toolkit';
import { AgentState, TaskStatus } from '../../types';
import { AGENT_SEQUENCES } from '../../data/mockData';

const initialState: AgentState = {
  logs: [],
  status: 'idle',
  activeRepoId: null,
};

/**
 * Thunk to simulate the Agent's lifecycle.
 * It iterates through a mock sequence of logs with delays 
 * to mimic real-time AI processing.
 */
export const runAgentTask = createAsyncThunk(
  'agent/runTask',
  async (repoId: string, { dispatch }) => {
    // We start by clearing previous state
    dispatch(agentSlice.actions.prepareForTask(repoId));

    const sequence = AGENT_SEQUENCES.REFactor;

    for (const message of sequence) {
      // Simulate a variable delay between agent "thoughts"
      const delay = Math.floor(Math.random() * 1000) + 800;
      await new Promise((resolve) => setTimeout(resolve, delay));

      // Append the new log to the terminal
      dispatch(agentSlice.actions.addLog(`[${new Date().toLocaleTimeString()}] ${message}`));
    }

    return repoId;
  }
);

export const agentSlice = createSlice({
  name: 'agent',
  initialState,
  reducers: {
    // Sets up the initial state when a developer clicks "Run Agent"
    prepareForTask: (state, action: PayloadAction<string>) => {
      state.activeRepoId = action.payload;
      state.status = 'running';
      state.logs = [`Initializing Agent environment for: ${action.payload}...`];
    },
    // Simple reducer to push new logs into the array
    addLog: (state, action: PayloadAction<string>) => {
      state.logs.push(action.payload);
    },
    // Resets everything to close the drawer or stop the task
    resetAgent: (state) => {
      state.status = 'idle';
      state.logs = [];
      state.activeRepoId = null;
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(runAgentTask.pending, (state) => {
        state.status = 'running';
      })
      .addCase(runAgentTask.fulfilled, (state) => {
        state.status = 'success';
        state.logs.push("✨ Agent task completed. Pull Request generated.");
      })
      .addCase(runAgentTask.rejected, (state) => {
        state.status = 'failure';
        state.logs.push("❌ Agent encountered an error during execution.");
      });
  },
});

export const { addLog, resetAgent, prepareForTask } = agentSlice.actions;
export default agentSlice.reducer;