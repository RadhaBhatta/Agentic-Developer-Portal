import React, { useEffect, useRef } from 'react';
import { useAppSelector, useAppDispatch } from '../../app/hooks';
import { resetAgent, runAgentTask } from './agentSlice';
import { LogStream } from './LogStream';
import { AgentStatus } from './AgentStatus';
import { Button } from '../../components/ui/Button';

export const AgentDrawer = () => {
  const { logs, status, activeRepoId } = useAppSelector((state) => state.agent);
  const dispatch = useAppDispatch();
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTo({
        top: scrollRef.current.scrollHeight,
        behavior: 'smooth',
      });
    }
  }, [logs]);

  if (!activeRepoId) return null;

  return (
    <div className="fixed inset-y-0 right-0 w-[480px] bg-slate-900 border-l border-slate-800 shadow-2xl flex flex-col z-50">
      {/* Header */}
      <div className="p-4 border-b border-slate-800 flex items-center justify-between bg-slate-900/50 backdrop-blur-md">
        <div>
          <h3 className="text-sm font-bold text-white">Agent Execution</h3>
          <p className="text-xs text-slate-500">Target: {activeRepoId}</p>
        </div>
        <button onClick={() => dispatch(resetAgent())} className="text-slate-500 hover:text-white transition-colors">
          ✕
        </button>
      </div>

      {/* Status Bar */}
      <div className="px-4 py-2 bg-slate-950/50 border-b border-slate-800">
        <AgentStatus />
      </div>

      {/* Terminal Content */}
      <div 
        ref={scrollRef}
        className="flex-1 overflow-y-auto p-4 bg-black/40 font-mono text-[13px] scrollbar-thin scrollbar-thumb-slate-800"
      >
        <LogStream logs={logs} />
      </div>

      {/* Footer Actions */}
      <div className="p-4 border-t border-slate-800 bg-slate-900/80">
        {status === 'success' ? (
          <Button className="w-full" onClick={() => window.open('#', '_blank')}>
            View Resulting Pull Request
          </Button>
        ) : (
          <Button 
            variant="secondary" 
            className="w-full" 
            disabled={status === 'running'}
            onClick={() => dispatch(runAgentTask(activeRepoId))}
          >
            {status === 'running' ? 'Agent Working...' : 'Retry Task'}
          </Button>
        )}
      </div>
    </div>
  );
};