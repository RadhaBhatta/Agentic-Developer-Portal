import { combineReducers } from '@reduxjs/toolkit';
import agentReducer from '../features/agent/agentSlice';
import repoReducer from '../features/repositories/repoSlice';

const rootReducer = combineReducers({
  agent: agentReducer,
  repositories: repoReducer,
});

export default rootReducer;