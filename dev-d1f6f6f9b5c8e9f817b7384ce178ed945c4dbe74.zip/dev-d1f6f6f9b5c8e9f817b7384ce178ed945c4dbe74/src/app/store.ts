import { configureStore } from '@reduxjs/toolkit';
import agentReducer from '../features/agent/agentSlice';
import repoReducer from '../features/repositories/repoSlice';

export const store = configureStore({
  reducer: {
    agent: agentReducer,
    repositories: repoReducer,
  },
  // Middleware is automatically configured by RTK
});

// Infer the `RootState` and `AppDispatch` types from the store itself
export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;